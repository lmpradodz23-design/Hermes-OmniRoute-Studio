<#
  Hermes OmniRoute Studio — Windows RC runtime validation runbook
  Baseline SHA: f33d1918aeebedbb6b69cbb65eadd6a27851d123  (branch develop)

  WHAT THIS DOES (safe, non-destructive):
    * Pre-flight the Windows toolchain and disk.
    * Prove HEAD == f33d1918 (never overwrites your tree).
    * Non-destructively BACK UP userData / HERMES_HOME / state.db (copy only).
    * Run the platform-agnostic source suites on Windows.
    * Build the NATIVE Windows installer (npm run dist:win → NSIS + MSI) and
      capture path + size + SHA256 into the evidence folder.
    * Print an interactive checklist for the runtime/E2E gates that a human
      must observe (cold start, restart, LOCAL_ONLY network capture, E2E).

  IT NEVER: deletes state.db, resets a database, clears memory/config, removes
  the old install, or force-pushes. Runtime gates use an ISOLATED test profile
  (a throwaway HERMES_HOME) so your real data is never touched.

  Run from an elevated-if-needed PowerShell:
    cd C:\Users\zodyp\Documents\Codex\Hermes-OmniRoute
    powershell -ExecutionPolicy Bypass -File .\audit\runtime-evidence\f33d1918\windows-validation.ps1
#>

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Repo       = 'C:\Users\zodyp\Documents\Codex\Hermes-OmniRoute'
$FrozenSha  = 'f33d1918aeebedbb6b69cbb65eadd6a27851d123'
$EvidenceDir= Join-Path $Repo 'audit\runtime-evidence\f33d1918'
$Stamp      = Get-Date -Format 'yyyyMMdd-HHmmss'
$Log        = Join-Path $EvidenceDir "windows-validation-$Stamp.log"
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null

function Say($m){ $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $m; Write-Host $line; Add-Content -Path $Log -Value $line }

Say "=== Hermes OmniRoute Windows validation — baseline $FrozenSha ==="

# ── 0. Pre-flight ──────────────────────────────────────────────────────────
Say "--- Pre-flight ---"
Say ("Windows: " + (Get-CimInstance Win32_OperatingSystem).Caption + " " + [Environment]::OSVersion.Version)
Say ("Arch: " + $env:PROCESSOR_ARCHITECTURE)
foreach ($t in 'node','npm','python','git') {
  try { $v = & $t --version 2>&1; Say ("{0}: {1}" -f $t, ($v -join ' ')) } catch { Say ("{0}: NOT FOUND" -f $t) }
}
$free = (Get-PSDrive C).Free / 1GB
Say ("Free disk C:: {0:N1} GB" -f $free)
if ($free -lt 15) { Say "WARNING: <15 GB free — a native build may fail." }

# ── 1. Git verification (read-only) ────────────────────────────────────────
Say "--- Git verification ---"
Push-Location $Repo
$head = (git rev-parse HEAD).Trim()
Say ("HEAD: " + $head)
Say ("Branch: " + (git branch --show-current))
if ($head -ne $FrozenSha) {
  Say "MISMATCH: HEAD != $FrozenSha. Investigate before building. NOT overwriting anything."
  Say "Stop here and reconcile (git fetch; git log --oneline -5)."
  Pop-Location; exit 2
}
Say "HEAD matches the frozen baseline."
Pop-Location

# ── 2. Non-destructive backup of user data ─────────────────────────────────
Say "--- Non-destructive backup ---"
$BackupRoot = Join-Path $env:USERPROFILE ("Hermes-RC-backup-" + $Stamp)
$dataPaths = @(
  (Join-Path $env:APPDATA 'Hermes OmniRoute Studio'),
  (Join-Path $env:APPDATA 'hermes'),
  (Join-Path $env:USERPROFILE '.hermes'),
  $env:HERMES_HOME
) | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique
if ($dataPaths) {
  New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null
  foreach ($p in $dataPaths) {
    $dest = Join-Path $BackupRoot ([IO.Path]::GetFileName($p.TrimEnd('\')))
    Say ("Copying (no delete): {0} -> {1}" -f $p, $dest)
    Copy-Item -Path $p -Destination $dest -Recurse -Force -ErrorAction SilentlyContinue
  }
  Say ("Backup at: " + $BackupRoot)
} else {
  Say "No existing userData/HERMES_HOME found (fresh-install scenario) — nothing to back up."
}

# ── 3. state.db integrity (read-only, if present) ──────────────────────────
Say "--- state.db integrity (non-destructive) ---"
$stateDbs = $dataPaths | ForEach-Object { Get-ChildItem -Path $_ -Filter 'state.db' -Recurse -ErrorAction SilentlyContinue } | Select-Object -First 3
foreach ($db in $stateDbs) {
  try {
    $q = & python -c "import sqlite3,sys; c=sqlite3.connect(sys.argv[1]); print('quick_check', c.execute('PRAGMA quick_check').fetchone()[0]); print('integrity', c.execute('PRAGMA integrity_check').fetchone()[0])" $db.FullName 2>&1
    Say ("state.db {0}: {1}" -f $db.FullName, ($q -join ' | '))
  } catch { Say ("state.db check skipped ({0}): {1}" -f $db.FullName, $_) }
}

# ── 4. Source suites on Windows (platform-agnostic; optional but recommended) ─
Say "--- Source suites (Windows) ---"
Push-Location $Repo
if (-not (Test-Path 'node_modules')) { Say "Installing root deps (npm ci)..."; npm ci --no-audit --no-fund 2>&1 | Tee-Object -Append $Log }
Push-Location 'apps\desktop'
Say "tsc electron..."; npx tsc --noEmit -p tsconfig.electron.json 2>&1 | Tee-Object -Append $Log; Say ("tsc exit: " + $LASTEXITCODE)
Say "electron vitest (updater + concurrency)..."; npx vitest run electron/update-marker.test.ts electron/update-marker.concurrency.test.ts electron/update-backoff.test.ts electron/update-decision.test.ts electron/update-policy.test.ts 2>&1 | Tee-Object -Append $Log
Say "  ^ NOTE: the concurrency test forks OS processes; on Windows this exercises NTFS O_EXCL/link semantics — the true target platform."
Pop-Location
Pop-Location

# ── 5. NATIVE Windows build → installer ────────────────────────────────────
Say "--- Native Windows build (npm run dist:win) ---"
Push-Location (Join-Path $Repo 'apps\desktop')
$buildStart = Get-Date
Say ("BUILD_COMMAND: npm run dist:win")
npm run dist:win 2>&1 | Tee-Object -Append $Log
$buildExit = $LASTEXITCODE
Say ("BUILD_EXIT_CODE: " + $buildExit)
Say ("BUILD duration: " + ((Get-Date) - $buildStart))
if ($buildExit -ne 0) { Say "BUILD FAILED — investigate the log above, fix root cause, rebuild. Do NOT proceed to install."; Pop-Location; exit 3 }

# Locate the installer(s) electron-builder produced.
$outDirs = @('dist_electron','release','dist\electron','out') | ForEach-Object { Join-Path $Repo ('apps\desktop\' + $_) } | Where-Object { Test-Path $_ }
$installers = @()
foreach ($d in $outDirs) { $installers += Get-ChildItem -Path $d -Recurse -Include '*.exe','*.msi' -ErrorAction SilentlyContinue }
$installers = $installers | Where-Object { $_.Name -notmatch 'elevate|Uninstall' } | Sort-Object Length -Descending
if (-not $installers) { Say "No .exe/.msi found under known output dirs — check electron-builder 'directories.output' in package.json build config." }
foreach ($i in $installers) {
  $sha = (Get-FileHash -Algorithm SHA256 -Path $i.FullName).Hash
  Say ("INSTALLER: {0}" -f $i.FullName)
  Say ("  SIZE: {0:N0} bytes" -f $i.Length)
  Say ("  SHA256: {0}" -f $sha)
  Add-Content -Path (Join-Path $EvidenceDir 'installers.txt') -Value ("{0}`t{1}`t{2}" -f $i.FullName, $i.Length, $sha)
}
Pop-Location

Say "=== AUTOMATED PORTION COMPLETE ==="
Say ""
Say "############################################################################"
Say "# INTERACTIVE RUNTIME GATES — a human must observe these with the NEW build. #"
Say "# Use an ISOLATED test profile so your real data is never touched:           #"
Say "#   `$env:HERMES_HOME = Join-Path `$env:TEMP 'hermes-rc-test'                  #"
Say "#   New-Item -ItemType Directory -Force -Path `$env:HERMES_HOME               #"
Say "############################################################################"
@'
[ ] INSTALL the new build (version 0.17.0-omniroute.1). Confirm it is NOT the old v0.20.4.
[ ] COLD START: fully close Hermes, kill residual electron/node/python, launch NEW build.
      PASS = Electron up + renderer loads + backend reaches READY (check desktop.log / backend log),
      updater does NOT kill the backend, UI operational. (Open window alone is NOT pass.)
[ ] RESTART x3: close → confirm teardown (no orphan electron/node/python, no venv lock,
      no stale .hermes-update-in-progress) → reopen. Backend READY each time, no boot loop.
[ ] FORK GUARD: on this fork checkout, confirm auto-update does NOT run / backend not killed /
      MANUAL_REQUIRED-or-skip / no destructive pull to main.
[ ] UPDATE BACKOFF: force a controlled update failure → backoff persisted (inspect the backoff
      file) → backend recovers → reopen → updater does NOT immediately retry → READY, no loop.
[ ] VENV BLOCKER: hold a venv .pyd open → confirm detection, safe abort, backoff, recovery.
[ ] CORRUPT BACKOFF: in the TEST profile only, write truncated/invalid backoff JSON → app does
      not crash, does not enable a destructive update, backend READY.
[ ] ATOMIC LOCK (runtime): launch two update attempts near-simultaneously → exactly 1 winner;
      loser does not kill backend / spawn updater / overwrite marker.
[ ] LOCAL_ONLY (BLOCKER): enable local_only. With a network capture running (Fiddler/Wireshark/
      Proxifier or `Get-NetTCPConnection`), attempt cloud providers (OpenAI/Anthropic/Gemini/
      OpenRouter), remote memory (mem0/Supermemory), cloud embeddings/vision/image/video, and a
      background/subagent call. EXPECT: ZERO cloud egress containing content. Then force the LOCAL
      model to fail → EXPECT local error/recovery, NEVER a cloud fallback. Allow Ollama/local.
      Record observed traffic. Any content egress = FAIL.
[ ] E2E (real UI→IPC→backend→UI, no fake buttons): Agents, Subagents (LOCAL_ONLY inherited →
      child cloud DENY), Goals (pause/resume survives restart), Memory/Starmap, Computer Use,
      Product Studio, Security Research→RAPTOR (adapter/lifecycle; runtime may be
      BLOCKED_BY_EXTERNAL_DEPENDENCY), WhatsApp→OpenWA (up to WAITING_FOR_HUMAN_QR_SCAN),
      Terminal, Files/Artifacts/Diff, Preview, Settings.
[ ] TOKEN-IN-URL (P1) & FS-BOUNDARIES (P1): reproduce media/download + file selection; verify no
      token in URL/history/Referer/logs; verify no traversal/UNC/symlink/other-drive escape.
[ ] ELECTRON SECURITY: contextIsolation on, sandbox, no nodeIntegration in renderer, preload
      allowlist, shell.openExternal guarded, CSP, no secret leakage to renderer.
[ ] pt-BR, ACCESSIBILITY (keyboard/focus/ARIA/contrast/zoom), VISUAL QA (1920x1080/1440x900/1366x768).
[ ] FIRST-RUN / OFFLINE / CRASH-RECOVERY / PROCESS-HYGIENE per the mission.
[ ] INSTALLER ARTIFACT SECRET SCAN: unpack the produced installer and confirm no .env / tokens /
      state.db / sessions / credentials / QR-auth were bundled.
'@ | ForEach-Object { Say $_ }
Say "Evidence log: $Log"
Say "Fill the checklist results into GATE_MATRIX.md and re-run this script after any source fix + rebuild."
