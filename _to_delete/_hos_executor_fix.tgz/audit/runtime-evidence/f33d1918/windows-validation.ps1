<#
  Hermes OmniRoute Studio - Windows RC runtime validation runbook
  Baseline SHA: f33d1918aeebedbb6b69cbb65eadd6a27851d123  (branch develop)

  This file is PURE ASCII and safe for Windows PowerShell 5.1 (which mis-reads
  non-ASCII in UTF-8-no-BOM files) AND PowerShell 7. The SQLite check lives in a
  separate state-db-check.py (no fragile inline-python quoting).

  WHAT IT DOES (safe, non-destructive):
    Preflight   - toolchain + disk + verify HEAD == f33d1918 + non-destructive
                  backup of userData/HERMES_HOME + read-only state.db PRAGMA check.
    SourceTests - tsc electron + updater/concurrency vitest on Windows.
    Build       - npm run dist:win (NSIS + MSI), capture installer path/size/SHA256.
    Runtime     - print the interactive checklist for the human-observed gates.

  IT NEVER deletes state.db, resets a database, clears memory/config, removes the
  old install, force-pushes, or publishes stable. Runtime gates use an ISOLATED
  test HERMES_HOME so real data is untouched.

  RUN (from the repo root):
    powershell -ExecutionPolicy Bypass -File .\audit\runtime-evidence\f33d1918\windows-validation.ps1 -Phase Preflight
    ...then -Phase SourceTests, -Phase Build, -Phase Runtime  (or -Phase All)
#>

[CmdletBinding()]
param(
  [ValidateSet('Preflight','SourceTests','Build','Runtime','All')]
  [string]$Phase = 'All'
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Repo        = 'C:\Users\zodyp\Documents\Codex\Hermes-OmniRoute'
$FrozenSha   = 'f33d1918aeebedbb6b69cbb65eadd6a27851d123'
$EvidenceDir = Join-Path $Repo 'audit\runtime-evidence\f33d1918'
$Stamp       = Get-Date -Format 'yyyyMMdd-HHmmss'
$Log         = Join-Path $EvidenceDir ('windows-validation-' + $Stamp + '.log')
New-Item -ItemType Directory -Force -Path $EvidenceDir | Out-Null

function Say([string]$m) {
  $line = '[' + (Get-Date -Format 'HH:mm:ss') + '] ' + $m
  Write-Host $line
  Add-Content -Path $Log -Value $line
}

# Resolved once in Preflight, reused by later phases in an All run.
$script:DataPaths = @()

function Invoke-Preflight {
  Say '=== PREFLIGHT ==='

  # -- toolchain + disk --
  try { $os = (Get-CimInstance Win32_OperatingSystem).Caption } catch { $os = 'unknown' }
  Say ('Windows: ' + $os + ' ' + [Environment]::OSVersion.Version.ToString())
  Say ('Arch: ' + $env:PROCESSOR_ARCHITECTURE)
  foreach ($t in @('node','npm','python','git')) {
    try { $v = (& $t --version 2>&1 | Out-String).Trim(); Say ($t + ': ' + $v) }
    catch { Say ($t + ': NOT FOUND') }
  }
  $free = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
  Say ('Free disk C: ' + $free + ' GB')
  if ($free -lt 15) { Say 'WARNING: less than 15 GB free - a native build may fail.' }

  # -- git verification (read-only) --
  Push-Location $Repo
  try {
    $head = (& git rev-parse HEAD | Out-String).Trim()
    $branch = (& git branch --show-current | Out-String).Trim()
    Say ('HEAD: ' + $head)
    Say ('Branch: ' + $branch)
    if ($head -ne $FrozenSha) {
      Say ('MISMATCH: HEAD != ' + $FrozenSha + '. NOT overwriting anything. Reconcile before building.')
      throw 'HEAD does not match the frozen baseline.'
    }
    Say 'HEAD matches the frozen baseline.'
  }
  finally { Pop-Location }

  # -- resolve user-data locations (used by backup + state.db) --
  $candidates = @(
    (Join-Path $env:APPDATA 'Hermes OmniRoute Studio'),
    (Join-Path $env:APPDATA 'hermes'),
    (Join-Path $env:USERPROFILE '.hermes'),
    $env:HERMES_HOME
  )
  $script:DataPaths = @($candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique)

  # -- non-destructive backup (copy only) --
  if ($script:DataPaths.Count -gt 0) {
    $backupRoot = Join-Path $env:USERPROFILE ('Hermes-RC-backup-' + $Stamp)
    New-Item -ItemType Directory -Force -Path $backupRoot | Out-Null
    foreach ($p in $script:DataPaths) {
      $leaf = Split-Path -Path $p.TrimEnd('\') -Leaf
      $dest = Join-Path $backupRoot $leaf
      Say ('Backup (copy, no delete): ' + $p + ' -> ' + $dest)
      Copy-Item -Path $p -Destination $dest -Recurse -Force -ErrorAction SilentlyContinue
    }
    Say ('Backup at: ' + $backupRoot)
  }
  else {
    Say 'No existing userData/HERMES_HOME found (fresh-install scenario) - nothing to back up.'
  }

  # -- state.db integrity (read-only, via the separate python helper) --
  $checker = Join-Path $EvidenceDir 'state-db-check.py'
  $dbs = @()
  foreach ($p in $script:DataPaths) {
    $dbs += Get-ChildItem -Path $p -Filter 'state.db' -Recurse -ErrorAction SilentlyContinue
  }
  $dbs = $dbs | Select-Object -First 3
  if (($dbs | Measure-Object).Count -eq 0) {
    Say 'STATE_DB=NOT_APPLICABLE_FRESH_PROFILE (no state.db found in known locations)'
  }
  elseif (-not (Test-Path $checker)) {
    Say ('state.db present but helper missing: ' + $checker)
  }
  else {
    foreach ($db in $dbs) {
      $res = (& python $checker $db.FullName 2>&1 | Out-String).Trim()
      Say ('state.db ' + $db.FullName + ': ' + $res)
    }
  }

  Say 'WINDOWS_EXECUTOR_PREFLIGHT=PASS'
}

function Invoke-SourceTests {
  Say '=== SOURCE TESTS (Windows) ==='
  Push-Location $Repo
  try {
    if (-not (Test-Path 'node_modules')) {
      Say 'Installing root deps (npm ci)...'
      & npm ci --no-audit --no-fund 2>&1 | Tee-Object -Append $Log
    }
    Push-Location 'apps\desktop'
    try {
      Say 'tsc electron...'
      & npx tsc --noEmit -p tsconfig.electron.json 2>&1 | Tee-Object -Append $Log
      Say ('tsc exit: ' + $LASTEXITCODE)

      Say 'electron vitest (updater + concurrency)...'
      & npx vitest run electron/update-marker.test.ts electron/update-marker.concurrency.test.ts electron/update-backoff.test.ts electron/update-decision.test.ts electron/update-policy.test.ts 2>&1 | Tee-Object -Append $Log
      Say ('vitest exit: ' + $LASTEXITCODE)
      Say 'NOTE: the concurrency test forks OS processes; on Windows this exercises NTFS O_EXCL/link semantics - the true target platform.'
    }
    finally { Pop-Location }
  }
  finally { Pop-Location }
}

function Invoke-Build {
  Say '=== NATIVE WINDOWS BUILD (npm run dist:win) ==='
  Push-Location (Join-Path $Repo 'apps\desktop')
  try {
    $start = Get-Date
    Say 'BUILD_COMMAND: npm run dist:win'
    & npm run dist:win 2>&1 | Tee-Object -Append $Log
    $buildExit = $LASTEXITCODE
    Say ('BUILD_EXIT_CODE: ' + $buildExit)
    Say ('BUILD duration: ' + ((Get-Date) - $start).ToString())
    if ($buildExit -ne 0) {
      throw 'BUILD FAILED - investigate the log, fix root cause, rebuild. Do NOT install.'
    }

    $outRoots = @('dist_electron','release','dist\electron','out') |
      ForEach-Object { Join-Path $Repo ('apps\desktop\' + $_) } |
      Where-Object { Test-Path $_ }
    $installers = @()
    foreach ($d in $outRoots) {
      $installers += Get-ChildItem -Path $d -Recurse -Include '*.exe','*.msi' -ErrorAction SilentlyContinue
    }
    $installers = $installers | Where-Object { $_.Name -notmatch 'elevate|Uninstall' } | Sort-Object Length -Descending
    if (($installers | Measure-Object).Count -eq 0) {
      Say 'No .exe/.msi found - check electron-builder directories.output in the build config.'
    }
    foreach ($i in $installers) {
      $sha = (Get-FileHash -Algorithm SHA256 -Path $i.FullName).Hash
      Say ('INSTALLER: ' + $i.FullName)
      Say ('  SIZE: ' + $i.Length + ' bytes')
      Say ('  SHA256: ' + $sha)
      Add-Content -Path (Join-Path $EvidenceDir 'installers.txt') -Value ($i.FullName + "`t" + $i.Length + "`t" + $sha)
    }
  }
  finally { Pop-Location }
}

function Show-RuntimeChecklist {
  Say '=== INTERACTIVE RUNTIME GATES (human-observed, with the NEW build) ==='
  Say 'Use an ISOLATED test profile so real data is never touched:'
  Say '  $env:HERMES_HOME = Join-Path $env:TEMP "hermes-rc-test"'
  Say '  New-Item -ItemType Directory -Force -Path $env:HERMES_HOME'
  $items = @(
    '[ ] INSTALL the new build (version 0.17.0-omniroute.1). Confirm it is NOT the old v0.20.4.',
    '[ ] COLD START: fully close Hermes; kill residual electron/node/python; launch NEW build.',
    '    PASS = Electron up + renderer loads + backend reaches READY (verify in desktop/backend log),',
    '    updater does NOT kill the backend, UI operational. Open window alone is NOT pass.',
    '[ ] RESTART x3: close -> confirm teardown (no orphan electron/node/python, no venv lock, no',
    '    stale .hermes-update-in-progress) -> reopen. Backend READY each time, no boot loop.',
    '[ ] FORK GUARD: on this fork checkout, auto-update does NOT run / backend not killed /',
    '    MANUAL_REQUIRED-or-skip / no destructive pull to main.',
    '[ ] UPDATE BACKOFF: force a controlled update failure -> backoff persisted (inspect the file)',
    '    -> backend recovers -> reopen -> updater does NOT immediately retry -> READY, no loop.',
    '[ ] VENV BLOCKER: hold a venv .pyd open -> detection, safe abort, backoff, recovery.',
    '[ ] CORRUPT BACKOFF (TEST profile only): truncated/invalid backoff JSON -> no crash, no',
    '    destructive update enabled, backend READY.',
    '[ ] ATOMIC LOCK (runtime): two near-simultaneous update attempts -> exactly 1 winner; loser',
    '    does not kill backend / spawn updater / overwrite marker.',
    '[ ] LOCAL_ONLY (BLOCKER): enable local_only. With a network capture running (Wireshark/Fiddler/',
    '    Proxifier or Get-NetTCPConnection), attempt cloud providers (OpenAI/Anthropic/Gemini/',
    '    OpenRouter), remote memory (mem0/Supermemory), cloud embeddings/vision/image/video, and a',
    '    background/subagent call. EXPECT: ZERO cloud egress containing content. Then force the LOCAL',
    '    model to fail -> EXPECT local error/recovery, NEVER a cloud fallback. Allow Ollama/local.',
    '    Any content egress = FAIL.',
    '[ ] E2E (real UI->IPC->backend->UI, no fake buttons): Agents, Subagents (LOCAL_ONLY inherited',
    '    -> child cloud DENY), Goals (pause/resume survives restart), Memory/Starmap, Computer Use,',
    '    Product Studio, Security Research->RAPTOR (may be BLOCKED_BY_EXTERNAL_DEPENDENCY),',
    '    WhatsApp->OpenWA (up to WAITING_FOR_HUMAN_QR_SCAN), Terminal, Files/Artifacts/Diff,',
    '    Preview, Settings.',
    '[ ] TOKEN-IN-URL (P1) and FS-BOUNDARIES (P1): reproduce media/download + file selection; no',
    '    token in URL/history/Referer/logs; no traversal/UNC/symlink/other-drive escape.',
    '[ ] ELECTRON SECURITY: contextIsolation on, sandbox, no nodeIntegration in renderer, preload',
    '    allowlist, shell.openExternal guarded, CSP, no secret leakage to renderer.',
    '[ ] pt-BR, ACCESSIBILITY (keyboard/focus/ARIA/contrast/zoom), VISUAL QA (1920x1080/1440x900/1366x768).',
    '[ ] FIRST-RUN / OFFLINE / CRASH-RECOVERY / PROCESS-HYGIENE per the mission.',
    '[ ] INSTALLER ARTIFACT SECRET SCAN: unpack the produced installer; confirm no .env / tokens /',
    '    state.db / sessions / credentials / QR-auth were bundled.'
  )
  foreach ($it in $items) { Say $it }
  Say ('Evidence log: ' + $Log)
  Say 'Fill results into GATE_MATRIX.md; re-run this script after any source fix + rebuild.'
}

# -- dispatch --
Say ('=== Hermes OmniRoute Windows validation - phase: ' + $Phase + ' ===')
switch ($Phase) {
  'Preflight'   { Invoke-Preflight }
  'SourceTests' { Invoke-SourceTests }
  'Build'       { Invoke-Build }
  'Runtime'     { Show-RuntimeChecklist }
  'All'         { Invoke-Preflight; Invoke-SourceTests; Invoke-Build; Show-RuntimeChecklist }
}
Say '=== phase complete ==='
