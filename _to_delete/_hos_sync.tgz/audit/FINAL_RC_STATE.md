# Hermes OmniRoute Studio — Final RC State (pre-publish)

Baseline: `275dad4` · Branch target: `oss/develop` · **NOT published** (awaiting your `.bat`).

This closes the two source gaps you flagged before push, plus the findings from
the final 2-agent adversarial round. GitHub stays source of truth; SOURCE_PASS is
distinguished from RUNTIME_PASS (runtime items remain for the Windows executor).

## Meta targets

| Target | State |
|---|---|
| `P0_SOURCE_OPEN` | **0** |
| `LOCAL_ONLY_EMBEDDINGS` | **SOURCE_PASS** |
| `LOCAL_ONLY_MEMORY_EGRESS` | **SOURCE_PASS** |
| `UPDATER_ATOMIC_LOCK` | **SOURCE_PASS** |

## Gap 1 — LOCAL_ONLY embeddings / memory egress

Single fail-closed dispatch-boundary gate (no per-plugin policy duplication):

- `MemoryProvider.local_only_denial()` (base, **fail-closed**): any provider that
  does not prove local-only safety is denied under local-only. Checked at the one
  activation chokepoint in `agent_init` before `add_provider()`/`initialize()`; a
  raising self-check counts as denial.
- `mem0` override resolves config from disk at activation (pre-`initialize`),
  inspecting embedder/llm/vector_store routes — scheme'd URLs, bare host:port,
  and `api_base` remap; embedded on-disk stores (`path=`) allowed, a URL-valued
  `path` still denied.
- `hindsight` override: cloud denied; `local_external` denied unless loopback
  api_url; `local_embedded` denied unless the embedded fact-extraction LLM route
  is local (embeddings are in-process).
- `mem0` PostHog telemetry forced OFF under local-only (env + client shutdown),
  before any mem0 import — closes the metadata-egress path the route gate can't see.
- Proxy indirection closed: the loopback credential proxy refuses to forward to a
  non-loopback upstream under local-only (`hermes_cli/proxy/server.py`).
- Reuses `agent/local_only.egress_denial_reason` / `_is_loopback_url` everywhere.

Tests (all green): `test_local_only_memory_dispatch.py`, `test_local_only_memory_egress.py`,
`test_local_only_aux_egress.py`, `test_local_only_loopback_parser.py`,
`test_proxy.py` (incl. neuter-canary), `test_mem0_backend.py` (telemetry force-off).

## Gap 2 — Updater cross-process atomic lock

- `claimUpdateMarker` now publishes atomically: a **complete** temp file +
  `fs.linkSync` (atomic exclusive create; EEXIST for the loser). The marker is
  never observed empty, so a concurrent self-healing reader can't prune-and-steal
  it. Write/link failure fails **closed**. `writeUpdateMarker` made atomic
  (temp + rename).
- All three destructive handoff paths now go through the atomic claim:
  Windows `applyUpdates`, macOS/Linux `applyUpdatesPosixHandoff`, and
  `handOffWindowsBootstrapRecovery` (with its own owner-scoped `finally` release,
  since it is outside `applyUpdates`' try/finally).

Tests (all green): `update-marker.test.ts` (atomic-publish / no-litter / loser-safe),
full electron suite 1588 passed / 8 skipped / 0 failed; `tsc -p tsconfig.electron.json` clean.

## Adversarial round 2 — verdicts after fixes

- Security (LOCAL_ONLY): **F1 CLOSED** (mem0 gate no longer reads uninitialized
  state), **N1 HIGH CLOSED** (telemetry), **N2 CLOSED** (default on-disk qdrant
  activates; N2b URL-in-path closed), **N3 CLOSED** for enumerated keys. No live
  egress bypass.
- QA/Concurrency (updater): **CRITICAL-1 CLOSED** (atomic link publish),
  **CRITICAL-2 CLOSED** (all handoff paths claim). No path lets two destructive
  updates run.

## Residuals (non-blocking, documented — not egress/double-update)

- N1 timing edge is version-specific to the pinned mem0; mainline reads the flag
  at runtime, and the early forced-off + client shutdown cover it.
- N3 route-key list is a denylist (inherent); unreachable with mem0's real
  provider surface (backends read only `*_base_url`).
- Updater: pre-`#74782` staged-updater branch pins the marker to the desktop pid
  that dies at `app.quit()` — pre-existing documented tradeoff, not introduced.
- `linkSync` assumes a hard-link-capable FS (always true for HERMES_HOME on
  NTFS/APFS/ext4); non-link FS fails closed (never a double-update).

## Deferred to Windows executor (RUNTIME, not source)

- Electron P1 token-in-URL, P1 fs-read scope.
- All RUNTIME_PASS validation on the real product (boot-loop reproduction,
  live local-only egress canaries).
